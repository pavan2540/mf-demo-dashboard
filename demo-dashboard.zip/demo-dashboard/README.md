# Micro-Frontends-and-Module-Federation
This is an example template to break down several apps into smaller parts and then show them into one big app using Micro-Frontends and Module Federation principles.\
\
**Micro-Frontends:** Home, Chat, Mail, Teams\
**Host App:** Host\
\
**How to Build and Run the Micro-Frontends:**
- **Home:** cd home && npm install && ng serve
- **Chat:** cd chat && npm install && ng serve
- **Mail:** cd mail && npm install && ng serve
- **Teams:** cd teams && npm install && ng serve

**How to Build and Run the Host App:** cd host && npm install && ng serve
